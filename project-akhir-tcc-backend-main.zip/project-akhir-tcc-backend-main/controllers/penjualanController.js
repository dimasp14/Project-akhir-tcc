const db = require("../db");

exports.getPenjualan = async (req, res) => {
  const [rows] = await db.execute(`
    SELECT lp.*, sb.nama_barang FROM laporan_penjualan lp
    JOIN stok_barang sb ON lp.barang_id = sb.id
  `);
  res.json(rows);
};

exports.addPenjualan = async (req, res) => {
  const { barang_id, jumlah_terjual } = req.body;
  const [barang] = await db.execute(
    "SELECT harga_satuan FROM stok_barang WHERE id = ?",
    [barang_id]
  );
  if (!barang.length)
    return res.status(400).json({ message: "Barang tidak ditemukan" });

  const total_harga = barang[0].harga_satuan * jumlah_terjual;
  await db.execute(
    "INSERT INTO laporan_penjualan (barang_id, jumlah_terjual, total_harga) VALUES (?, ?, ?)",
    [barang_id, jumlah_terjual, total_harga]
  );
  await db.execute("UPDATE stok_barang SET jumlah = jumlah - ? WHERE id = ?", [
    jumlah_terjual,
    barang_id,
  ]);
  res.status(201).json({ message: "Laporan ditambahkan" });
};
