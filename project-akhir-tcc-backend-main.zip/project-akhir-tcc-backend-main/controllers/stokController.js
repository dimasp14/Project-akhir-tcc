const db = require("../db");

exports.getAllStok = async (req, res) => {
  const [rows] = await db.execute("SELECT * FROM stok_barang");
  res.json(rows);
};

exports.addStok = async (req, res) => {
  const { nama_barang, jumlah, harga_satuan } = req.body;
  await db.execute(
    "INSERT INTO stok_barang (nama_barang, jumlah, harga_satuan) VALUES (?, ?, ?)",
    [nama_barang, jumlah, harga_satuan]
  );
  res.status(201).json({ message: "Barang ditambahkan" });
};

exports.updateStok = async (req, res) => {
  const { id } = req.params;
  const { nama_barang, jumlah, harga_satuan } = req.body;
  await db.execute(
    "UPDATE stok_barang SET nama_barang=?, jumlah=?, harga_satuan=? WHERE id=?",
    [nama_barang, jumlah, harga_satuan, id]
  );
  res.json({ message: "Barang diperbarui" });
};

exports.deleteStok = async (req, res) => {
  const { id } = req.params;
  await db.execute("DELETE FROM stok_barang WHERE id=?", [id]);
  res.json({ message: "Barang dihapus" });
};
