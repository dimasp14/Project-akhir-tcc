require("dotenv").config();
const express = require("express");
const cors = require("cors");
const app = express();
const PORT = process.env.PORT || 5000;

// const corsOptions = {
//   origin: "http://localhost:5173",
//   methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
//   allowedHeaders: ["Content-Type", "Authorization"],
//   credentials: true,
// };

// app.use(cors(corsOptions));
// app.options("*", cors(corsOptions));
app.use(cors());
app.use(express.json());

const authRoutes = require("./routes/authRoute");
const stokRoutes = require("./routes/stokRoute");
const penjualanRoutes = require("./routes/penjualanRoute");

app.use("/api/auth", authRoutes);
app.use("/api/stok", stokRoutes);
app.use("/api/penjualan", penjualanRoutes);

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
