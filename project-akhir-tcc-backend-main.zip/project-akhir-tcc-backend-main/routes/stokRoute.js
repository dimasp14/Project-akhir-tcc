const express = require("express");
const router = express.Router();
const stokController = require("../controllers/stokController");
const authenticateToken = require("../middleware/authMiddleware");

router.get("/", authenticateToken, stokController.getAllStok);
router.post("/", authenticateToken, stokController.addStok);
router.put("/:id", authenticateToken, stokController.updateStok);
router.delete("/:id", authenticateToken, stokController.deleteStok);

module.exports = router;
