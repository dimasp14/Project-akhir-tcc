const express = require("express");
const router = express.Router();
const penjualanController = require("../controllers/penjualanController");
const authenticateToken = require("../middleware/authMiddleware");

router.get("/", authenticateToken, penjualanController.getPenjualan);
router.post("/", authenticateToken, penjualanController.addPenjualan);

module.exports = router;
