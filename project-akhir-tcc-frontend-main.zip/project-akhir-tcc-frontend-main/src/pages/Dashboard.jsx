import React, { useState, useEffect } from "react";
import axios from "axios";

const Dashboard = () => {
  const [tab, setTab] = useState("stok");
  const [stok, setStok] = useState([]);
  const [penjualan, setPenjualan] = useState([]);
  const [formPenjualan, setFormPenjualan] = useState({
    barang_id: "",
    jumlah_terjual: "",
  });
  const [formStok, setFormStok] = useState({
    id: null,
    nama_barang: "",
    jumlah: "",
    harga_satuan: "",
  });
  const [editMode, setEditMode] = useState(false);
  const [barangList, setBarangList] = useState([]);

  const token = localStorage.getItem("token");

  const fetchStok = async () => {
    const res = await axios.get(
      "https://backend-project-akhir-884920877595.asia-southeast2.run.app/api/stok",
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    setStok(res.data);
    setBarangList(res.data);
  };

  const fetchPenjualan = async () => {
    const res = await axios.get(
      "https://backend-project-akhir-884920877595.asia-southeast2.run.app/api/penjualan",
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    setPenjualan(res.data);
  };

  useEffect(() => {
    fetchStok();
    fetchPenjualan();
  }, []);

  const handleInputPenjualan = (e) => {
    const { name, value } = e.target;
    setFormPenjualan({ ...formPenjualan, [name]: value });
  };

  const submitPenjualan = async (e) => {
    e.preventDefault();
    try {
      await axios.post(
        "https://backend-project-akhir-884920877595.asia-southeast2.run.app/api/penjualan",
        formPenjualan,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setFormPenjualan({ barang_id: "", jumlah_terjual: "" });
      fetchPenjualan();
    } catch (err) {
      alert("Gagal menambahkan penjualan");
    }
  };
  const handleLogout = () => {
    localStorage.removeItem("token");
    window.location.href = "/login"; // arahkan ke halaman login
  };

  const handleInputStok = (e) => {
    const { name, value } = e.target;
    setFormStok({ ...formStok, [name]: value });
  };

  const submitStok = async (e) => {
    e.preventDefault();
    try {
      if (editMode) {
        await axios.put(
          `https://backend-project-akhir-884920877595.asia-southeast2.run.app/api/stok/${formStok.id}`,
          formStok,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
      } else {
        await axios.post(
          "https://backend-project-akhir-884920877595.asia-southeast2.run.app/api/stok",
          formStok,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
      }
      setFormStok({ id: null, nama_barang: "", jumlah: "", harga_satuan: "" });
      setEditMode(false);
      fetchStok();
    } catch (err) {
      alert("Gagal menyimpan data stok");
    }
  };

  const editStok = (barang) => {
    setFormStok(barang);
    setEditMode(true);
  };

  const deleteStok = async (id) => {
    if (window.confirm("Yakin ingin menghapus barang ini?")) {
      try {
        await axios.delete(
          `https://backend-project-akhir-884920877595.asia-southeast2.run.app/api/stok/${id}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        fetchStok();
      } catch (err) {
        alert("Gagal menghapus data");
      }
    }
  };

  return (
    <div className="flex items-start justify-center min-h-screen w-screen bg-gradient-to-br from-blue-100 via-white to-blue-50">
      <button
        onClick={handleLogout}
        className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition"
      >
        Logout
      </button>
      <div className="flex flex-col w-full max-w-6xl p-6">
        <h1 className="text-4xl font-bold text-center text-indigo-700 mb-8">
          Dashboard
        </h1>
        {/* Tab Menu */}
        <div className="flex justify-center gap-4 mb-8">
          <button
            onClick={() => setTab("stok")}
            className={`px-5 py-2 rounded-lg text-sm font-medium transition ${
              tab === "stok"
                ? "bg-indigo-600 text-white shadow"
                : "bg-white text-gray-600 border"
            }`}
          >
            Stok Barang
          </button>
          <button
            onClick={() => setTab("penjualan")}
            className={`px-5 py-2 rounded-lg text-sm font-medium transition ${
              tab === "penjualan"
                ? "bg-indigo-600 text-white shadow"
                : "bg-white text-gray-600 border"
            }`}
          >
            Penjualan
          </button>
        </div>

        {/* Tab Konten */}
        <div className="bg-white rounded-xl shadow-lg p-6 w-full">
          {/* Stok Tab */}
          {tab === "stok" && (
            <div>
              <h2 className="text-2xl font-semibold mb-4">
                {editMode ? "Edit Barang" : "Tambah Barang"}
              </h2>
              <form
                onSubmit={submitStok}
                className="grid md:grid-cols-3 gap-4 mb-6"
              >
                <input
                  type="text"
                  name="nama_barang"
                  placeholder="Nama Barang"
                  value={formStok.nama_barang}
                  onChange={handleInputStok}
                  className="border p-3 rounded-md w-full"
                  required
                />
                <input
                  type="number"
                  name="jumlah"
                  placeholder="Jumlah"
                  value={formStok.jumlah}
                  onChange={handleInputStok}
                  className="border p-3 rounded-md w-full"
                  required
                />
                <input
                  type="number"
                  name="harga_satuan"
                  placeholder="Harga Satuan"
                  value={formStok.harga_satuan}
                  onChange={handleInputStok}
                  className="border p-3 rounded-md w-full"
                  required
                />
                <div className="col-span-3 flex gap-3 mt-2">
                  <button
                    type="submit"
                    className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
                  >
                    {editMode ? "Update Barang" : "Tambah Barang"}
                  </button>
                  {editMode && (
                    <button
                      type="button"
                      onClick={() => {
                        setFormStok({
                          id: null,
                          nama_barang: "",
                          jumlah: "",
                          harga_satuan: "",
                        });
                        setEditMode(false);
                      }}
                      className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500 transition"
                    >
                      Batal
                    </button>
                  )}
                </div>
              </form>

              <h3 className="text-xl font-semibold mb-4">Daftar Stok Barang</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {stok.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 border rounded-lg text-gray-600 bg-gray-50 shadow"
                  >
                    <p className="font-bold">{item.nama_barang}</p>
                    <p>Jumlah: {item.jumlah} pcs</p>
                    <p>Harga: Rp{item.harga_satuan.toLocaleString()}</p>
                    <div className="mt-2 flex gap-2">
                      <button
                        onClick={() => editStok(item)}
                        className="bg-yellow-500 text-white px-3 py-1 rounded hover:bg-yellow-600"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => deleteStok(item.id)}
                        className="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700"
                      >
                        Hapus
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Penjualan Tab */}
          {tab === "penjualan" && (
            <div>
              <h2 className="text-2xl font-semibold mb-4">Tambah Penjualan</h2>
              <form
                onSubmit={submitPenjualan}
                className="grid md:grid-cols-2 gap-4 mb-6"
              >
                <select
                  name="barang_id"
                  value={formPenjualan.barang_id}
                  onChange={handleInputPenjualan}
                  className="border p-3 rounded-md w-full"
                  required
                >
                  <option value="">Pilih Barang</option>
                  {barangList.map((barang) => (
                    <option key={barang.id} value={barang.id}>
                      {barang.nama_barang}
                    </option>
                  ))}
                </select>
                <input
                  type="number"
                  name="jumlah_terjual"
                  placeholder="Jumlah Terjual"
                  value={formPenjualan.jumlah_terjual}
                  onChange={handleInputPenjualan}
                  className="border p-3 rounded-md w-full"
                  required
                />
                <div className="col-span-2 mt-2">
                  <button
                    type="submit"
                    className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition"
                  >
                    Simpan Penjualan
                  </button>
                </div>
              </form>

              <h3 className="text-xl font-semibold mb-4">Riwayat Penjualan</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {penjualan.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 border rounded-lg bg-gray-50 text-gray-600 shadow"
                  >
                    <p>ID Barang: {item.barang_id}</p>
                    <p>Nama Barang: {item.nama_barang}</p>
                    <p>Jumlah Terjual: {item.jumlah_terjual} pcs</p>
                    <p>Total Harga: Rp{item.total_harga.toLocaleString()}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
