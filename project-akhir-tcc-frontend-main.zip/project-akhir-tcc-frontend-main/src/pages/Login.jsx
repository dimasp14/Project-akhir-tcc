import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const res = await axios.post(
        "https://backend-project-akhir-884920877595.asia-southeast2.run.app/api/auth/login",
        {
          username,
          password,
        }
      );
      localStorage.setItem("token", res.data.token);
      navigate("/dashboard");
    } catch (err) {
      alert("Login gagal, periksa kembali username atau password");
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen w-screen bg-gradient-to-br from-sky-200 via-white to-rose-100">
      <div className="flex justify-center items-center w-full h-full">
        <div className="backdrop-blur-lg bg-white/70 border border-white/30 rounded-3xl shadow-xl px-10 py-12 w-full max-w-md">
          <h2 className="text-3xl font-extrabold text-center text-indigo-600 mb-8">
            Selamat Datang
          </h2>
          <div className="space-y-4">
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-400 transition"
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-400 transition"
            />
          </div>
          <button
            onClick={handleLogin}
            className="mt-6 w-full bg-indigo-500 text-white py-3 rounded-xl hover:bg-indigo-600 transition font-semibold shadow-md"
          >
            Masuk
          </button>
          <p className="text-sm text-center mt-6 text-gray-700">
            Belum punya akun?{" "}
            <span
              onClick={() => navigate("/register")}
              className="text-indigo-600 font-medium hover:underline cursor-pointer"
            >
              Daftar di sini
            </span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
