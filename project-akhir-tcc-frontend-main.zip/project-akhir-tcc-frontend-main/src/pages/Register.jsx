import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Register = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleRegister = async () => {
    try {
      await axios.post(
        "https://backend-project-akhir-884920877595.asia-southeast2.run.app/api/auth/register",
        {
          username,
          password,
        }
      );
      alert("Registrasi berhasil, silakan login.");
      navigate("/login");
    } catch (err) {
      alert("Registrasi gagal. Cek kembali data Anda.");
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen w-screen bg-gradient-to-br from-green-100 via-white to-green-200">
      <div className="flex justify-center items-center w-full h-full">
        <div className="bg-white shadow-lg rounded-2xl px-10 py-8 w-full max-w-sm border border-green-100">
          <h2 className="text-3xl font-extrabold text-center text-green-700 mb-6">
            Register
          </h2>
          <div className="space-y-4">
            <input
              type="text"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-400 transition"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <input
              type="password"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-400 transition"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button
            onClick={handleRegister}
            className="mt-6 w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition font-semibold shadow"
          >
            Daftar
          </button>
          <p className="text-sm text-center mt-4 text-gray-600">
            Sudah punya akun?{" "}
            <span
              onClick={() => navigate("/login")}
              className="text-blue-500 hover:underline cursor-pointer"
            >
              Login di sini
            </span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;
